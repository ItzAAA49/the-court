
(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const SAVE_KEY='the-court-save-v1';
let state=null, activeTab='record', soundOn=true, audioCtx=null;
const names=['佐伯 直人','高橋 美咲','森田 和也','小野寺 玲子','黒田 修','石井 由香','村上 俊介','藤原 佳奈','松本 達也','西村 明','坂本 亮','山口 理恵','田中 誠','吉岡 未来','長谷川 誠司','青木 さくら','三浦 健','前田 由紀'];
const surnames=['佐伯','高橋','森田','小野寺','黒田','石井','村上','藤原','松本','西村','坂本','山口','田中','吉岡','長谷川','青木','三浦','前田','川村','大野'];
const given=['直人','美咲','和也','玲子','修','由香','俊介','佳奈','達也','明','亮','理恵','誠','未来','誠司','さくら','健','由紀','拓海','真帆'];
const places=['神奈川県川崎市','大阪府堺市','福岡県北九州市','北海道札幌市','愛知県豊田市','東京都北区','宮城県仙台市','広島県福山市','埼玉県川口市','千葉県船橋市','京都府宇治市','福岡県福岡市'];
const dates=['11月3日 午後8時40分','10月18日 午前6時15分','9月27日 午後10時05分','11月12日 午後1時20分','8月6日 午後7時55分','10月30日 午前0時18分','11月1日 午後4時32分','9月14日 午後9時10分'];
const contexts=['閉店後の小さな商店街','再開発が進む駅前ビル','郊外の住宅街にある集合住宅','夜間も人通りの多い繁華街','地域住民が利用する公共施設','古い商店が並ぶアーケード街','防犯カメラが設置された駐車場','大型台風の接近で人通りが少ない地域'];
const motives=['生活費の不足','長年の金銭トラブル','職場での対立','SNS上での口論','家族間の不和','事業上の損失','思い込みによる誤解','突発的な口論'];
const newsPool=[
 {h:'生成AIによる音声偽造、捜査と証拠評価に新たな課題',s:'専門家は「データの出所と改変履歴の検証が不可欠」と指摘。',body:'音声や画像を容易に加工できる技術が広がり、裁判で提出されるデジタル証拠の真正性が改めて問われている。専門家は、ファイルの出所、取得経路、保全状況、専門的な検証の有無を丁寧に確認する必要があると話す。技術への期待と不信が同時に高まるなか、裁判所には証拠を一つずつ吟味する姿勢が求められている。'},
 {h:'物価上昇続く、地域の小規模事業者に重い負担',s:'生活不安が広がる一方、犯罪被害への支援も議論に。',body:'食料品や光熱費の負担が続き、地域の小規模事業者や家計への影響が指摘されている。困窮を背景とする事件への支援策が議論される一方、被害に遭った人の生活再建も大きな課題だ。社会的背景を理解することと、犯罪の成立や責任を証拠に基づいて判断することは区別して考える必要がある。'},
 {h:'防犯カメラの設置拡大、プライバシーとの両立が焦点',s:'映像の保存期間と閲覧権限をめぐり、自治体が指針を検討。',body:'各地で防犯カメラの設置が進む一方、撮影範囲やデータの保管、第三者提供のあり方が課題となっている。映像は事件の解明に役立つ場合があるが、画角や時刻のずれ、画質、編集の有無などを確認しなければならない。映像に映っているというだけで、直ちに犯罪を断定できるわけではない。'},
 {h:'SNSでの告発投稿めぐり議論、公益性と個人の名誉をどう考える',s:'事実確認の手順、投稿の目的、表現の範囲が注目される。',body:'SNSで不正を告発する投稿が相次ぐなか、公益のための情報発信と個人の名誉を守る必要性の調整が議論されている。投稿内容の真偽だけでなく、公共性、目的、表現方法、裏付けの有無など、具体的な事情を丁寧に見ることが重要だ。'},
 {h:'大雨への備え急ぐ、自治体と住民が避難体制を再確認',s:'災害時の混乱に乗じた犯罪や支援物資の管理にも注意。',body:'各地で大雨への備えが進み、自治体は避難所や支援物資の管理体制を確認している。非常時には情報が錯綜し、通常とは異なる状況が生じる。事件の背景として災害や混乱が関係する場合も、当時の状況を具体的に把握し、推測だけで判断しないことが求められる。'},
 {h:'若年層の孤立と地域支援、再犯防止へ連携の動き',s:'更生支援と被害者支援の双方を考える議論が続く。',body:'家庭や職場、地域とのつながりを失った人への支援について、自治体や民間団体の連携が進んでいる。刑事司法の場面でも、責任の有無を証拠に基づいて判断したうえで、再犯防止や被害者の回復に向けた支援をどう組み立てるかが問われている。'},
 {h:'企業の情報管理に関心高まる、内部通報制度の運用を点検',s:'記録の保全と不利益取扱いの防止が課題に。',body:'企業や自治体で内部通報制度の運用を点検する動きが広がっている。通報者の保護、記録の保全、調査の独立性が重要とされる。内部告発や関係者の供述が事件の発端となる場合、動機だけで結論を急がず、客観的な裏付けと矛盾の有無を確認する必要がある。'}
];
const incidentPool={
 theft:['限定モデルの腕時計','売上金の入った封筒','業務用ノートPC','希少なコレクション商品','倉庫に保管されていた工具一式','店頭から消えた高額商品'],
 assault:['駐車スペースをめぐる口論','飲食店の順番待ちをめぐる口論','落とし物の扱いをめぐる口論','騒音への苦情から始まった口論','仕事上の連絡をめぐる口論'],
 damage:['公共施設の案内板','店舗入口のガラス扉','駐車場の精算機','地域イベント用の展示物','集合住宅の共用設備'],
 defamation:['地域企業の品質管理に関する投稿','自治会役員の金銭管理に関する投稿','店舗従業員の対応に関する投稿','公共事業の入札に関する投稿','学校行事の運営に関する投稿'],
 injury:['階段付近での転倒事故','工事現場近くでの接触','飲食店の入口での衝突','駐車場での押し合い','路地での口論後の負傷'],
 fraud:['架空の投資勧誘','修理費用の二重請求','オンライン取引の代金未返還','実在しない商品の販売','事業資金の募集を装った送金依頼'],
 murder:['被害者の自宅で発見された遺体','閉鎖された事務所で発生した死亡事件','山間部の別荘で発見された遺体','夜間の倉庫で発生した死亡事件','集合住宅の一室で発見された遺体']
};
const types=[
 {id:'theft',name:'窃盗事件',level:'軽微〜中程度',days:5,law:[['刑法 第235条','窃盗','他人の財物を窃取した場合に成立。法定刑は10年以下の拘禁刑又は50万円以下の罰金。']],acc:'閉店後の店舗から商品が持ち去られたとして、被告人が起訴された。',detail:'被害品は店の在庫と一致するが、現場の出入りを直接捉えた映像はない。',motive:'生活費の不足',news:[0,1,2,5],severity:2,
 evidence:[['防犯カメラ映像','現場付近の人物を記録した映像。顔の判別と時刻の正確性が争点。',8],['指紋・接触痕','商品保管箱から採取された接触痕。採取場所と混入可能性が争点。',7],['交通系ICの利用記録','現場周辺の駅で記録された利用履歴。本人利用かどうかが争点。',7],['目撃者の供述','近隣住民が見た人物の服装と移動方向に関する供述。',6],['被害品の保管状況','被告人の所持品から見つかった品の識別情報。入手経路が争点。',8]]},
 {id:'assault',name:'暴行事件',level:'軽微〜中程度',days:5,law:[['刑法 第208条','暴行','暴行を加え、傷害の結果が生じなかった場合。法定刑は2年以下の拘禁刑若しくは30万円以下の罰金又は拘留若しくは科料。'],['憲法 第37条','公平な公開裁判・証人審問','被告人には公平な裁判を受け、証人を審問する機会が保障される。']],acc:'飲食店の外で口論となり、被害者に暴行を加えたとして被告人が起訴された。',detail:'現場には複数の目撃者がいたが、供述の内容には食い違いがある。',motive:'職場での対立',news:[1,2,5],severity:2,
 evidence:[['店舗前の映像','口論から接触までを撮影した映像。死角と音声の欠落が争点。',8],['診断・受診記録','被害申告後の受診記録。暴行との因果関係が争点。',7],['目撃者Aの供述','被告人が先に手を出したとする供述。距離と視認時間が争点。',6],['目撃者Bの供述','被害者側から接近したとする供述。利害関係が争点。',6],['メッセージ履歴','事件直前のやり取り。挑発や事前の対立の有無が争点。',5]]},
 {id:'damage',name:'器物損壊事件',level:'軽微',days:4,law:[['刑法 第261条','器物損壊等','他人の物を損壊した場合。法定刑は3年以下の拘禁刑又は30万円以下の罰金若しくは科料。']],acc:'公共施設の設備が壊され、被告人が損壊行為をしたとして起訴された。',detail:'破損した時刻は特定されておらず、施設の利用者が複数いた。',motive:'突発的な口論',news:[2,4,5],severity:1,
 evidence:[['施設内カメラ','破損前後の様子を撮影した映像。保存時刻のずれが争点。',8],['工具の鑑定','現場の損傷痕と押収物の形状比較。個別性が争点。',7],['利用者の目撃証言','破損音を聞いた人物の供述。見たのか聞いたのかが争点。',5],['修理業者の報告','破損原因と推定時刻を記した報告書。専門性が争点。',7]]},
 {id:'defamation',name:'名誉毀損事件',level:'中程度',days:5,law:[['刑法 第230条','名誉毀損','公然と事実を摘示し、人の名誉を毀損した場合。法定刑は3年以下の拘禁刑又は50万円以下の罰金。'],['刑法 第230条の2','公共の利害に関する特例','公共の利害に関する事実で、専ら公益目的があり、真実性の証明がある場合の特例。'],['刑法 第232条','親告罪','名誉に対する罪は、告訴がなければ公訴を提起できない。']],acc:'被告人がインターネット上に投稿した内容が、被害者の社会的評価を低下させたとして起訴された。',detail:'投稿には社会的関心のある問題が含まれ、内容の真実性と公益目的が争われている。',motive:'SNS上での口論',news:[0,3,6],severity:2,
 evidence:[['投稿データ原本','問題となった投稿と公開範囲の記録。改変・切り抜きの有無が争点。',8],['投稿前の調査資料','被告人が投稿前に集めた情報。裏付けの程度が争点。',7],['関係者の証言','投稿内容の対象となった出来事についての供述。利害関係が争点。',6],['投稿後のやり取り','訂正や削除の要請に対する応答。目的や認識を推認する事情。',5],['専門家の評価','投稿が閲覧者に与える意味や文脈に関する意見。',5]]},
 {id:'injury',name:'傷害事件',level:'中程度〜重大',days:6,law:[['刑法 第204条','傷害','人の身体を傷害した場合。法定刑は15年以下の拘禁刑又は50万円以下の罰金。'],['憲法 第38条','自己に不利益な供述の強要禁止','強制等による自白は証拠にできず、自白だけを唯一の証拠として有罪にできない。']],acc:'被害者に重いけがを負わせたとして、被告人が傷害罪で起訴された。',detail:'事件前後の行動、負傷の原因、被告人の関与の程度が争点となっている。',motive:'長年の金銭トラブル',news:[1,2,4,5],severity:3,
 evidence:[['医師の診断書','負傷の部位と程度を記録。発生時期と原因の特定が争点。',8],['現場の血痕・痕跡','現場から採取された痕跡。採取手順と混入可能性が争点。',8],['通話・位置情報','事件前後の移動や連絡の履歴。端末の利用者が争点。',7],['被害者の供述','事件当時の状況についての供述。記憶の変化が争点。',6],['第三者の目撃証言','現場周辺で見た人物の行動。視認環境が争点。',6],['取調べ時の供述','被告人の供述内容と任意性。憲法38条との関係が争点。',5]]},
 {id:'fraud',name:'詐欺事件',level:'中程度〜重大',days:6,law:[['刑法 第246条','詐欺','人を欺いて財物を交付させた場合。法定刑は10年以下の拘禁刑。'],['刑事訴訟法 第317条','証拠裁判主義','事実の認定は証拠による。']],acc:'架空の投資話で金銭をだまし取ったとして、被告人が詐欺罪で起訴された。',detail:'資金の流れは追跡されているが、被告人が当初から欺く意思を持っていたかが争点。',motive:'事業上の損失',news:[0,1,5,6],severity:3,
 evidence:[['送金記録','複数口座を経由した資金の移動。資金の使途が争点。',8],['契約書・説明資料','投資内容とリスクの説明を記載した資料。作成者と説明内容が争点。',7],['被害者の供述','説明を受けた内容と認識についての供述。記憶と記録の一致が争点。',6],['端末内の履歴','計画段階のメッセージやファイル。作成日時と真正性が争点。',8],['事業の実態調査','実際に事業活動があったかを調べた報告。失敗と当初の欺罔の区別が争点。',7],['共犯者とされる人物の供述','関与した人物の供述。責任回避の可能性が争点。',5]]},
 {id:'murder',name:'殺人事件',level:'最重大',days:8,law:[['刑法 第199条','殺人','人を殺した場合。法定刑は死刑又は無期若しくは5年以上の拘禁刑。'],['憲法 第31条','法定手続の保障','法律の定める手続によらなければ、生命・自由を奪われず、刑罰を科されない。'],['刑事訴訟法 第336条','無罪判決','犯罪の証明がない場合、無罪の言渡しをしなければならない。']],acc:'被害者が死亡した事件について、被告人が殺害したとして起訴された。',detail:'直接証拠は乏しく、動機、死亡推定時刻、デジタル記録、供述の信用性が慎重に審理される。',motive:'家族間の不和',news:[0,2,4,5,6],severity:5,
 evidence:[['司法解剖鑑定書','死亡原因と推定時刻を示す専門的資料。推定幅と前提条件が争点。',9],['防犯カメラの連続映像','現場周辺の移動を記録した映像。未撮影区間の存在が争点。',8],['DNA・微物証','被害者の衣服等から採取された資料。移転・混入の可能性が争点。',9],['通信・位置情報','事件前後の端末の動き。本人が操作していたかが争点。',7],['近隣住民の証言','異音や人物の出入りについての供述。時刻の記憶が争点。',6],['被告人の供述','事件当日の行動についての供述。任意性と他の証拠との整合性が争点。',6],['専門家の追加意見','鑑定結果の別解釈。科学的な限界と反対尋問が争点。',7],['事件前の関係資料','動機とされる対立の経緯を示す資料。動機だけで犯人といえるかが争点。',5]]}
];
const stepNames=['起訴・冒頭陳述','証拠調べ','証人尋問','反対尋問','最終弁論','評議・判決'];
function randInt(n){return Math.floor(Math.random()*n)} function pick(a){return a[randInt(a.length)]} function clamp(n,a,b){return Math.max(a,Math.min(b,n))}
function person(){return pick(surnames)+' '+pick(given)}
function articleDate(day){let d=new Date(2026,10,20+day-1);return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`}
function say(s){$('#toast').textContent=s;$('#toast').classList.add('show');clearTimeout(say.t);say.t=setTimeout(()=>$('#toast').classList.remove('show'),2300)}
function beep(freq=520,dur=.08,type='sine'){if(!soundOn)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(.045,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+dur);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+dur)}catch(e){}}
function autoSave(){if(!state)return;try{localStorage.setItem(SAVE_KEY,JSON.stringify(state))}catch(e){}}
function save(){if(!state)return;autoSave();say('審理記録を保存しました');beep(660,.07)}
function load(){try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(e){return null}}
function uniqueName(except=[]){let n;do{n=person()}while(except.includes(n));return n}
function makeCase(){
 const used=state?.seen||[];let tpl,seed,signature,where,when,context,motive,specific,tries=0;
 do{tpl=pick(types);where=pick(places);when=pick(dates);context=pick(contexts);motive=pick(motives);specific=pick(incidentPool[tpl.id]);signature=[tpl.id,where,when,context,motive,specific].join('|');tries++}while(used.includes(signature)&&tries<500);
 seed=Math.random().toString(36).slice(2,9);
 let defendant=uniqueName(),victim=uniqueName([defendant]),prosecutor=uniqueName([defendant,victim]),defense=uniqueName([defendant,victim,prosecutor]);
 const truth=Math.random()<.63;let evidence=tpl.evidence.map((e,i)=>{
  let direction;
  if(truth){direction=[1,1,-1,1,-1,1,1,-1][i%8];if(Math.random()<.22)direction*=-1}
  else{direction=[-1,-1,1,-1,1,-1,-1,1][i%8];if(Math.random()<.3)direction*=-1}
  let q=clamp(e[2]+randInt(5)-2,2,10);if(direction<0&&Math.random()<.3)q=clamp(q-2,2,10);
  let detail=direction>0?[
   `記録は被告人の説明と一部一致し、検察側は「${e[0]}」が関与を示す事情と主張する。時刻・取得経路の確認が必要。`,
   `複数の資料と整合する箇所がある。事件の対象「${pick(['現場周辺の移動','関係者との連絡','物品の保管状況','事件直後の行動'])}」と関連するが、この資料だけで実行行為まで断定できるかは別問題。`,
   `検察側の主張を一定程度補強する内容。弁護側は、別の説明として「${pick(['第三者の関与','時刻記録のずれ','日常的な接触','記憶違い'])}」が可能だと反論している。`
  ]: [
   `被告人の説明を裏付ける可能性がある。弁護側は合理的な疑いが残ると主張する。`,
   `記録には別の解釈も成り立つ部分がある。検察側は他の証拠と合わせて評価すべきと反論。`,
   `供述・記録の一部に食い違いがある。とくに「${pick(['時刻','人物の識別','取得経路','記憶の変化'])}」について、信用性と証拠価値を慎重に検討する必要がある。`
  ];
  return {title:e[0],desc:e[1],quality:q,direction,detail:pick(detail),revealed:false,source:['物証','記録','供述','鑑定'][i%4]};
 });
 // Vary enough independent details without changing the statutory framework.
 const typeName=tpl.name;
 const defendantAge=randInt(38)+20;
 const caseNo='TC-'+String((state?.cases||0)+1).padStart(4,'0')+'-'+seed.toUpperCase();
 const intro=`${where}の${context}で、${when}に発生した事件。${tpl.acc} 事件の中心となる対象は「${specific}」。関係者の間には${motive}を背景とする事情もあったとされる。現場の状況と当日の行動を一つずつ検討する必要がある。`;
 return {id:caseNo,seed,signature,kind:tpl.id,name:typeName,defendantAge,defendantJob:pick(['会社員','自営業','契約社員','無職','飲食店勤務','事務職','配送業','技術職']),defendantAddress:where+' '+pick(['中央区','東区','西区','南町','北町'])+' '+(randInt(8)+1)+'丁目',witnessName:uniqueName([defendant,victim,prosecutor,defense]),defendantBirth:'西暦'+(2026-defendantAge)+'年'+(randInt(12)+1)+'月'+(randInt(28)+1)+'日',level:tpl.level,days:tpl.days,day:1,defendant,victim,prosecutor,defense,where,when,context,motive,specific,truth,summary:intro,detail:tpl.detail,law:tpl.law,evidence,actions:2,stage:0,log:[],opened:false,closing:false,verdict:null,news:null,newspapers:[],belief:50,publicEffect:randInt(7)-3,severity:tpl.severity,hiddenTwist:pick(['事件当日の通信記録に時刻のずれがある','目撃者と当事者には過去の面識があった','現場の照明は通常より暗かった','重要資料の保管担当者が途中で交代していた','事件直後に第三者から匿名の連絡があった','当日の天候が現場の状況に影響していた'])};
}
function pushLog(txt){state.case.log.unshift({day:state.case.day,txt});if(state.case.log.length>18)state.case.log.length=18}
function phaseFor(day,c){if(day===1)return ['起訴・冒頭陳述','冒頭手続'];if(day===c.days)return ['最終弁論','結審前'];if(day===c.days-1)return ['最終弁論','弁論'];if(day===2)return ['証拠調べ','証拠調べ'];if(day===3)return ['証人尋問','証人尋問'];return ['反対尋問','追加審理']}
function makeNews(c){let pool=newsPool.filter(x=>x.h!==c.news?.h);let item=pick(pool.length?pool:newsPool);c.news=item;c.newspapers.push({date:articleDate(c.day),...item});}
function beginCase(){state.case=makeCase();state.seen.push(state.case.signature);if(state.seen.length>500)state.seen=state.seen.slice(-500);state.dayTotal=state.dayTotal||0;state.case.actions=2;makeNews(state.case);pushLog('新件 '+state.case.id+' の審理を開始。法廷が開廷した。');pushLog('検察側と弁護側に冒頭陳述を求めた。');render();autoSave();}
function initGame(){state={dayTotal:0,cases:0,trust:72,integrity:70,experience:0,seen:[],history:[],case:null,removed:false,suspicion:0,ballots:0};$('#titleScreen').classList.add('hidden');$('#gameScreen').classList.remove('hidden');beginCase();}
function resumeGame(){let v=load();if(!v||!v.case){say('保存された審理記録がありません');return}state=v;$('#titleScreen').classList.add('hidden');$('#gameScreen').classList.remove('hidden');render();say('前回の審理を再開しました')}
function actorSpeech(kind){let c=state.case,day=c.day;const revealed=c.evidence.filter(e=>e.revealed);const plus=revealed.filter(e=>e.direction>0).length,minus=revealed.filter(e=>e.direction<0).length;
 if(kind==='prosecution'){
  if(day===1)return `本件の争点は、被告人が${c.when}に現場で実行行為に及んだかどうかです。検察官として、動機、現場の状況、提出証拠を総合して立証します。`;
  if(plus>minus){let last=[...revealed].reverse().find(e=>e.direction>0);return `新たに確認された「${last?.title||'提出資料'}」は、${c.specific}をめぐる経緯と整合する部分があります。検察側は、これを他の資料と合わせて評価すべきと主張します。弁護側の別解釈だけで全体の証明力が失われるわけではありません。`}
  return `弁護側は疑問を指摘していますが、検察官は証拠全体の連関を重視します。なお、未確認の点については引き続き追加資料を提出します。`;
 }
 if(kind==='defense'){
  if(day===1)return `被告人は起訴内容を争っています。疑いがあることと、犯罪を証明できたことは同じではありません。検察側には、合理的な疑いを超える立証が求められます。`;
  if(minus>=plus){let last=[...revealed].reverse().find(e=>e.direction<0);return `「${last?.title||'提出資料'}」には別の解釈が成り立ちます。さらに、${c.hiddenTwist}。${c.specific}をめぐる経緯について、検察側の仮説だけで結論を急ぐべきではありません。`}
  return `一部の資料が検察側の主張と一致しても、それだけで実行行為や故意まで証明されたとは限りません。取得手順と証拠の信用性を確認してください。`;
 }
 return `裁判所は、当事者の主張を対等に聴き、証拠の出所・信用性・相互の整合性を確認します。報道や世論ではなく、法廷に提出された証拠と法令に基づいて判断します。`;
}
function dayNarrative(){let c=state.case;let p=phaseFor(c.day,c);let summary;
 if(c.day===1)summary=`本日、${c.where}で起きた「${c.name}」の審理を開始します。被告人 ${c.defendant}。検察官 ${c.prosecutor}、弁護人 ${c.defense}。${c.summary}`;
 else if(c.day===c.days)summary=`審理最終日です。これまで提出された証拠は${c.evidence.filter(e=>e.revealed).length}点。検察側と弁護側に最後の主張を求め、判決を言い渡してください。`;
 else summary=`第${c.day}回公判。${p[0]}を行います。${c.detail} ${c.evidence.filter(e=>e.revealed).length}点の証拠が調べられています。`;
 $('#hearingKicker').textContent=`DAY ${String(c.day).padStart(2,'0')} / ${p[0].toUpperCase()}`;$('#hearingTitle').textContent=c.day===1?'冒頭陳述 — 事件の輪郭':c.day===c.days?'結審 — 判決の時':p[0]+' — 証拠と主張';$('#phaseTag').textContent=p[1];$('#hearingSummary').textContent=summary;
 $('#speeches').innerHTML=`<div class="speech"><div class="speech-mark">検</div><div><div class="speech-label">PROSECUTION · ${esc(c.prosecutor)}</div><div class="speech-text">${esc(actorSpeech('prosecution'))}</div></div></div><div class="speech defense"><div class="speech-mark">弁</div><div><div class="speech-label">DEFENSE · ${esc(c.defense)}</div><div class="speech-text">${esc(actorSpeech('defense'))}</div></div></div>`;
 const row=$('#actionRow');row.innerHTML='';
 if(c.day<c.days){
  [['証拠を調べる','evidence','証拠品の記録を確認'],['証人を尋問する','witness','証言の信用性を確かめる'],['被告人に質問する','defendant','説明と供述の整合性を確認']].forEach(([label,kind,desc])=>{let b=document.createElement('button');b.className='action-btn secondary';b.textContent=label;b.disabled=c.actions<=0;b.title=desc;b.dataset.action=kind;row.appendChild(b)});
  let next=document.createElement('button');next.className='action-btn gold';next.textContent=`次の日へ進む　→`;next.dataset.action='next';row.appendChild(next);
  $('#actionHint').textContent=`本日の調査行動：残り ${c.actions} 回。証拠調べ・尋問は日ごとに2回まで。調査を終えたら次の日へ進んでください。`;
 }else{
  let v1=document.createElement('button');v1.className='action-btn gold';v1.textContent='判決を下す';v1.dataset.action='verdict';row.appendChild(v1);
  $('#actionHint').textContent='審理は結審しました。証拠と法令を確認したうえで、有罪・無罪を判断してください。';
 }
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function revealEvidence(kind,index=null){let c=state.case;let arr=c.evidence.filter(e=>!e.revealed);if(!arr.length){say('新たに調べられる証拠はありません');return}
 let e=index!==null?c.evidence[index]:null;
 if(!e&&kind==='witness'){e=arr.find(x=>x.source==='供述')||arr[0]}
 else if(!e&&kind==='defendant'){e=arr.find(x=>x.title.includes('供述')||x.title.includes('履歴'))||arr[0]}
 else if(!e){e=arr.find(x=>x.source==='物証'||x.source==='記録'||x.source==='鑑定')||arr[0]}
 e.revealed=true;c.actions--;let delta=e.direction*e.quality*1.45;c.belief=clamp(c.belief+delta,5,95);
 const actionName=kind==='witness'?'証人尋問':kind==='defendant'?'被告人質問':'証拠調べ';pushLog(`${actionName}：${e.title}を確認。${e.direction>0?'検察側の主張を補強し得る':'弁護側の疑問を補強し得る'}内容が明らかになった。`);
 $('#speeches').insertAdjacentHTML('beforeend',`<div class="speech judge"><div class="speech-mark">裁</div><div><div class="speech-label">COURT NOTE · ${actionName}</div><div class="speech-text">${esc(e.title)}：${esc(e.detail)}</div></div></div>`);
 beep(kind==='witness'?430:560,.1);render();autoSave();say('証拠を記録に追加しました');
}
function nextDay(){let c=state.case;if(c.day>=c.days)return;c.day++;state.dayTotal++;c.actions=2;makeNews(c);pushLog(`第${c.day}回公判。${phaseFor(c.day,c)[0]}を開始。朝刊「${c.news.h}」。`);beep(390,.12,'triangle');render();autoSave();}
function render(){if(!state||!state.case)return;let c=state.case;
 $('#topDay').textContent=`DAY ${String(state.dayTotal+1).padStart(2,'0')}`;$('#topTrust').textContent=`${state.trust}%`;$('#topCases').textContent=String(state.cases).padStart(2,'0');
 $('#ticketNo').textContent='DOCKET NO. '+c.id;$('#ticketTitle').textContent=c.name;$('#ticketMeta').innerHTML=`被告人　${esc(c.defendant)}<br>罪名　${esc(c.name)}<br>重要度　${esc(c.level)}<br>事件地　${esc(c.where)}`;
 $('#newsDate').textContent=articleDate(c.day);$('#newsHeadline').textContent=c.news.h;$('#newsSub').textContent=c.news.s;
 $('#progressList').innerHTML=Array.from({length:c.days},(_,i)=>{let d=i+1,txt=d===1?'冒頭陳述':d===c.days?'判決前日':d===c.days-1?'最終弁論':d===2?'証拠調べ':d===3?'証人尋問':'追加審理';let cls=d<c.day?'done':d===c.day?'active':'';return `<div class="progress-step ${cls}"><div class="step-dot">${d<c.day?'✓':d}</div><span>${txt}</span></div>`}).join('');
 dayNarrative();$('#logCount').textContent=`${c.log.length} RECORDS`;$('#logList').innerHTML=c.log.map(l=>`<div class="log-item"><time>D${String(l.day).padStart(2,'0')}</time>${esc(l.txt)}</div>`).join('');
 renderTab();}
function renderTab(){let c=state.case,root=$('#tabContent');
 const evidenceMarkup=()=>c.evidence.map((e)=>`<div class="evidence-card ${e.revealed?'':'locked'}"><div class="evidence-top"><div class="evidence-title">${e.revealed?'◆':'▧'} ${esc(e.title)}</div><span class="evidence-chip">${e.revealed?e.source:'未調査'}</span></div><div class="evidence-desc">${e.revealed?esc(e.detail):'まだ十分に調べられていない資料。裁判官として調査を命じることができます。'}</div>${e.revealed?'':`<button class="small-btn" data-evidence-index="${c.evidence.indexOf(e)}" ${c.actions<=0||c.day>=c.days?'disabled':''}>資料を調査する</button>`}</div>`).join('');
 if(activeTab==='record'){root.innerHTML=`<div class="sidebar-section-title">事件概要 / CASE FILE</div><div class="file-paper"><div class="file-stamp">裁判所保管</div><div class="file-kicker">DOCKET ${esc(c.id)}</div><h3>${esc(c.name)}</h3><p>${esc(c.summary)}</p><div class="file-rule"></div><dl><dt>被告人</dt><dd>${esc(c.defendant)}</dd><dt>年齢</dt><dd>${c.defendantAge||35}歳</dd><dt>職業</dt><dd>${esc(c.defendantJob||'会社員')}</dd><dt>住所</dt><dd>${esc(c.defendantAddress||c.where)}</dd><dt>生年月日</dt><dd>${esc(c.defendantBirth||'記録なし')}</dd><dt>事件発生</dt><dd>${esc(c.when)}</dd><dt>発生場所</dt><dd>${esc(c.where)} / ${esc(c.context)}</dd><dt>起訴罪名</dt><dd>${esc(c.name)}</dd><dt>背景事情</dt><dd>${esc(c.motive)}</dd></dl><div class="file-rule"></div><div class="file-foot">事件記録・第${c.day}回公判 / 機密資料</div></div><button class="sidebar-action" id="recordPrint">事件記録を表示・印刷</button><div class="sidebar-section-title">審理進行</div><div class="progress-list" id="progressList">${Array.from({length:c.days},(_,i)=>{let d=i+1,txt=d===1?'冒頭陳述':d===c.days?'判決前日':d===c.days-1?'最終弁論':d===2?'証拠調べ':d===3?'証人尋問':'追加審理';let cls=d<c.day?'done':d===c.day?'active':'';return `<div class="progress-step ${cls}"><div class="step-dot">${d<c.day?'✓':d}</div><span>${txt}</span></div>`}).join('')}</div><div class="side-note">裁判官の心得：報道や世論ではなく、法廷に提出された証拠と法令に基づいて判断してください。</div>`; }
 else if(activeTab==='question'){root.innerHTML=`<div class="sidebar-section-title">裁判官による質問 / QUESTIONS</div><p class="side-intro">質問する相手を選び、事実関係を明らかにしてください。質問には本日の行動回数を1回消費します。</p><div class="person-action-card"><div class="person-token defendant-token">被</div><div><b>被告人 ${esc(c.defendant)}</b><small>事件当日の行動・動機・供述の矛盾</small></div><button data-ask="defendant" ${c.actions<=0||c.day>=c.days?'disabled':''}>質問</button></div><div class="person-action-card"><div class="person-token witness-token">証</div><div><b>証人 ${esc(c.witnessName||'関係者')}</b><small>目撃状況・記憶・利害関係</small></div><button data-ask="witness" ${c.actions<=0||c.day>=c.days?'disabled':''}>質問</button></div><div class="person-action-card"><div class="person-token prosecutor-token">検</div><div><b>検察官 ${esc(c.prosecutor)}</b><small>立証方針・証拠の意味</small></div><button data-ask="prosecution" ${c.actions<=0||c.day>=c.days?'disabled':''}>質問</button></div><div class="person-action-card"><div class="person-token defense-token">弁</div><div><b>弁護人 ${esc(c.defense)}</b><small>反証・合理的な疑い</small></div><button data-ask="defense" ${c.actions<=0||c.day>=c.days?'disabled':''}>質問</button></div><div class="action-meter"><span>本日の行動回数</span><b>${c.actions} / 2</b></div>`; }
 else if(activeTab==='defense'||activeTab==='prosecution'){let defense=activeTab==='defense',who=defense?'弁護人':'検察官',name=defense?c.defense:c.prosecutor;root.innerHTML=`<div class="sidebar-section-title">${defense?'DEFENSE COUNSEL':'PUBLIC PROSECUTOR'}</div><div class="counsel-card ${defense?'defense-card':'prosecution-card'}"><div class="counsel-avatar">${defense?'弁':'検'}</div><div><b>${who} ${esc(name)}</b><small>${defense?'被告人の権利を守り、検察の立証を検証する':'起訴事実を証拠により立証する'}</small></div></div><div class="counsel-statement"><div class="statement-label">現在の主張</div><p>${esc(actorSpeech(defense?'defense':'prosecution'))}</p></div><button class="sidebar-action" data-listen="${activeTab}" ${c.actions<=0||c.day>=c.days?'disabled':''}>${defense?'弁護人の意見を詳しく聞く':'検察官の意見を詳しく聞く'}</button><div class="side-note">双方の主張を聞いたうえで、裏付けとなる証拠と反対証拠を確認しましょう。</div>`; }
 else if(activeTab==='witness'){root.innerHTML=`<div class="sidebar-section-title">WITNESS STAND / 証人</div><div class="witness-profile"><div class="witness-portrait">証</div><h3>${esc(c.witnessName||'関係者')}</h3><p>事件現場周辺に居合わせた関係者。供述の正確性、観察条件、記憶の変化を確認してください。</p><div class="witness-facts"><span>証言テーマ</span><b>${esc(c.evidence.find(e=>e.source==='供述')?.title||'現場の状況')}</b><span>審理日</span><b>DAY ${c.day} / ${c.days}</b></div></div><button class="sidebar-action" data-ask="witness" ${c.actions<=0||c.day>=c.days?'disabled':''}>証人に尋問する</button><div class="side-note">証人の印象だけで信用性を決めず、供述と客観的資料の一致・不一致を確認してください。</div>`; }
 else if(activeTab==='verdict'){root.innerHTML=`<div class="sidebar-section-title">JUDGMENT / 判決</div><div class="verdict-prep"><div class="prep-seal">⚖</div><h3>判決の準備</h3><p>${c.day>=c.days?'審理は結審しました。記録を見直し、判決を言い渡せます。':'まだ審理中です。最終日まで証拠と双方の主張を確認してください。'}</p><div class="prep-row"><span>審理日数</span><b>${c.day} / ${c.days}日</b></div><div class="prep-row"><span>調査済み証拠</span><b>${c.evidence.filter(e=>e.revealed).length} / ${c.evidence.length}</b></div><div class="prep-row"><span>検察側の立証方向</span><b>${Math.round(c.belief)}%</b></div></div><button class="sidebar-action verdict-launch" id="sidebarVerdict" ${c.day<c.days?'disabled':''}>判決を下す　→</button><div class="side-note">合理的な疑いが残る場合は、被告人に不利益な推測で補わず、無罪の原則を検討してください。</div>`; }
 else if(activeTab==='evidence'){root.innerHTML=`<div class="sidebar-section-title">EVIDENCE / 証拠資料</div>${evidenceMarkup()}`;}
 else if(activeTab==='law'){root.innerHTML=c.law.map(([ref,title,desc])=>`<div class="law-card"><div class="law-title">${esc(title)}</div><div class="law-ref">${esc(ref)}</div><div class="law-desc">${esc(desc)}</div></div>`).join('')+`<div class="law-card"><div class="law-title">憲法・刑事手続の基本原則</div><div class="law-ref">憲法 第31条・第37条・第38条 ／ 刑事訴訟法 第317条・第336条</div><div class="law-desc">適正手続、証人審問、自白の任意性、証拠に基づく事実認定、犯罪の証明がない場合の無罪判決を意識してください。</div></div>`;}
 else {let count=c.evidence.filter(e=>e.revealed).length,plus=c.evidence.filter(e=>e.revealed&&e.direction>0).length,minus=count-plus;root.innerHTML=`<div class="paper-text">心証表示は調査済み資料を整理する補助情報です。数値だけで判決を決めないでください。</div><div class="meter-wrap"><div class="meter-head"><span>検察側の立証方向</span><b>${Math.round(c.belief)}%</b></div><div class="meter"><i style="width:${c.belief}%"></i></div></div><div class="meter-wrap"><div class="meter-head"><span>調査済み証拠</span><b>${count} / ${c.evidence.length}</b></div><div class="meter"><i style="width:${count/c.evidence.length*100}%"></i></div></div><div class="paper-text">検察側を補強し得る資料：${plus}点<br>弁護側の疑問を補強し得る資料：${minus}点<br>未調査：${c.evidence.length-count}点</div><button class="small-btn" id="hintBtn">判断の基本原則を見る</button>`;$('#hintBtn')?.addEventListener('click',()=>showModal('判断の基本原則',`<p>検察官が犯罪を立証する責任を負います。疑いが残る場合に、被告人に無実の証明を求めてはいけません。</p><p><b>憲法第38条第3項</b>：本人の自白が唯一の不利益な証拠である場合、有罪にできません。<br><b>刑事訴訟法第317条</b>：事実の認定は証拠によります。<br><b>刑事訴訟法第336条</b>：犯罪の証明がない場合は無罪判決を言い渡します。</p>`));}
}

function showModal(title,body,actions=''){let root=$('#modalRoot');root.innerHTML=`<div class="overlay" id="overlay"><div class="modal"><div class="modal-head"><div><div class="eyebrow" style="color:#8b714b">THE COURT / DOCUMENT</div><h2>${esc(title)}</h2></div><button class="modal-close" id="closeModal">×</button></div><div class="modal-body">${body}${actions}</div></div></div>`;$('#closeModal').onclick=()=>root.innerHTML='';$('#overlay').addEventListener('click',e=>{if(e.target.id==='overlay')root.innerHTML=''});}
function showNews(){let c=state.case,n=c.news;showModal('本日の朝刊',`<div class="newspaper"><div class="news-paper-mast">THE DAILY COURT</div><div class="news-paper-date">${articleDate(c.day)}　｜　朝刊　｜　法廷と社会</div><div class="news-paper-head">${esc(n.h)}</div><div class="news-paper-col">${esc(n.body)}<br><br>本紙は、司法が社会の信頼を得るためには、迅速さだけでなく、証拠に基づく丁寧な判断と、当事者双方の権利の保障が欠かせないと考える。</div></div><p>社会の空気は毎日変わります。しかし、裁判官は世論の圧力だけで有罪・無罪を決めることはできません。背景事情と法的判断を区別しましょう。</p>`);}
function sentenceOptions(){let id=state.case.kind;if(id==='murder')return [['拘禁刑5年','法定刑の下限を選択'],['拘禁刑10年','長期の拘禁刑'],['無期拘禁刑','最も重い選択肢の一つ']];if(id==='fraud')return [['執行猶予を検討','事情に応じた猶予判断'],['拘禁刑2年','短期の拘禁刑'],['拘禁刑5年','より重い拘禁刑']];if(id==='injury')return [['罰金','罰金刑を選択'],['拘禁刑1年','短期の拘禁刑'],['拘禁刑3年','より重い拘禁刑']];if(id==='theft'||id==='damage'||id==='assault'||id==='defamation')return [['罰金','罰金刑を選択'],['執行猶予を検討','拘禁刑に執行猶予を付す想定'],['拘禁刑1年','拘禁刑を選択']];return [['罰金','罰金刑'],['拘禁刑1年','拘禁刑']];}
function verdictModal(){let c=state.case;const body=`<p>審理記録を見直し、判決を選択してください。これは架空事件のゲーム上の判断です。実際の事件では、訴因、証拠能力、構成要件、違法性、責任、量刑事情などの検討が必要です。</p><div class="verdict-options"><button class="verdict-choice" data-verdict="guilty"><b>有罪</b><span>起訴された犯罪事実が、証拠により認定できると判断する。</span></button><button class="verdict-choice" data-verdict="notguilty"><b>無罪</b><span>犯罪の証明がない、または合理的な疑いが残ると判断する。</span></button></div><div id="sentenceBox" class="hidden"><b style="font:700 13px 'Noto Serif JP',serif">量刑を選択</b><p>有罪と判断した場合、法定刑の範囲と事件の事情を意識して選択してください。</p><div class="sentence-row" id="sentenceRow"></div></div><div class="choice-note">判決理由では、証拠の信用性、反対証拠、適用条文、疑いが残るかを説明します。社会の人気だけで判断しないでください。</div><div class="modal-actions"><button class="paper-btn alt" id="backVerdict">審理に戻る</button><button class="paper-btn" id="confirmVerdict" disabled>判決を言い渡す</button></div>`;
 showModal('判決の言い渡し',body);let selected=null,sentence=null;
 $$('[data-verdict]').forEach(b=>b.onclick=()=>{selected=b.dataset.verdict;$$('[data-verdict]').forEach(x=>x.style.borderColor=x===b?'#aa8955':'#c7beaf');let box=$('#sentenceBox');box.classList.toggle('hidden',selected!=='guilty');if(selected==='guilty'){$('#sentenceRow').innerHTML=sentenceOptions().map((s,i)=>`<button class="sentence-choice" data-sentence="${i}"><b>${s[0]}</b><br><small>${s[1]}</small></button>`).join('');$$('[data-sentence]').forEach(x=>x.onclick=()=>{sentence=Number(x.dataset.sentence);$$('[data-sentence]').forEach(y=>y.classList.toggle('selected',y===x));$('#confirmVerdict').disabled=false})}else{$('#confirmVerdict').disabled=false}});
 $('#backVerdict').onclick=()=>$('#modalRoot').innerHTML='';$('#confirmVerdict').onclick=()=>{if(!selected||(selected==='guilty'&&sentence===null))return;$('#modalRoot').innerHTML='';finishVerdict(selected,sentence)};
}
function finishVerdict(verdict,sentence){let c=state.case;let revealed=c.evidence.filter(e=>e.revealed);let score=clamp(50+revealed.reduce((a,e)=>a+e.direction*e.quality*1.45,0),0,100);let proof=score>=62;let right=(verdict==='guilty')===proof;let truthMatch=(verdict==='guilty')===c.truth;
 let fairness=right?12:-18;if(revealed.length<Math.ceil(c.evidence.length*.35))fairness-=5;if(c.severity>=4&&revealed.length<5)fairness-=4;
 let sentenceName=verdict==='guilty'?sentenceOptions()[sentence][0]:'無罪';let reason=verdict==='guilty'?`裁判所は、提出された証拠の相互関係から、起訴事実を認定できると判断しました。適用法令は${c.law[0][0]}です。量刑では、行為の態様、結果、動機、被害回復や反省などを個別に考慮します。`:`裁判所は、検察側の主張に疑問が残り、起訴事実を認定するには合理的な疑いを払拭できないと判断しました。${c.law[0][0]}の構成要件を満たす事実の証明が十分ではありません。`;
 state.trust=clamp(state.trust+fairness+(c.publicEffect),0,100);state.integrity=clamp(state.integrity+(right?8:-12),0,100);state.experience+=c.severity*10+revealed.length*2;state.cases++;state.history.unshift({id:c.id,name:c.name,verdict:sentenceName,proof:Math.round(score),right,truthMatch,day:c.day,reason});if(state.history.length>40)state.history.length=40;
 pushLog(`判決：${sentenceName}。${right?'記録上の証拠評価と整合した判断':'証拠評価または量刑に問題が残る判断'}と評価された。`);
 let scandal=state.trust<23||state.integrity<25||(!right&&state.cases%2===0);let publicVote=state.cases%4===0||state.trust<35;
 let ending=`<div class="result-banner"><h3>${verdict==='guilty'?'有罪判決':'無罪判決'}</h3><p>${esc(c.name)}　／　被告人 ${esc(c.defendant)}　／　${esc(sentenceName)}</p></div><p>${esc(reason)}</p><div class="result-score"><div class="score-box"><b>${Math.round(score)}%</b><small>証拠の心証値</small></div><div class="score-box"><b>${state.trust}%</b><small>国民の信頼</small></div><div class="score-box"><b>${state.integrity}%</b><small>裁判官の公正性</small></div></div><div class="choice-note">${right?'証拠に基づく判断として評価されました。':'判断に疑問が残りました。証拠の見落とし、十分な調査を行わなかった点、法令適用を再確認してください。'}<br>この結果はゲーム内の評価であり、現実の裁判結果を予測するものではありません。</div>`;
 if(publicVote)ending+=`<div class="danger-note"><b>国民信頼投票（ゲーム内の架空制度）</b><br>審理結果への不信が高まり、裁判官としての信任を問う投票が実施されます。支持率 ${state.trust}%。${state.trust<20?'解任の可能性が高まっています。':'信任を維持しました。次の事件で公正な判断を示してください。'}</div>`;
 if(scandal)ending+=`<div class="danger-note"><b>裁判官を狙う不穏な動き</b><br>判決への反発を背景に、匿名の脅迫状が届きました。警備が強化されます。次の事件では関係者との接触に注意が必要です。</div>`;
 ending+=`<div class="modal-actions"><button class="paper-btn" id="nextCaseBtn">次の事件へ　→</button></div>`;
 showModal('判決記録 — JUDGMENT',ending);$('#nextCaseBtn').onclick=()=>{if(publicVote&&state.trust<12){state.removed=true;gameOver();return}if(state.trust<=0||state.integrity<=0){gameOver();return}$('#modalRoot').innerHTML='';state.dayTotal+=1;beginCase();save()};
 beep(right?650:260,.22,right?'sine':'triangle');save();
}
function gameOver(){let body=`<div class="result-banner"><h3>任期終了 — 裁判官を失職</h3><p>国民の信頼と裁判所の公正性を失い、あなたの任期は終了しました。</p></div><p>あなたが担当した事件：${state.cases}件<br>獲得経験：${state.experience} XP<br>最終信頼度：${state.trust}%</p><p>この国民投票による失職制度は、ゲーム上の架空ルールです。実際の日本の裁判官の罷免・審査制度とは異なります。</p><div class="modal-actions"><button class="paper-btn" id="restartBtn">新しい任期を始める</button></div>`;showModal('THE COURT / END OF TERM',body);$('#restartBtn').onclick=()=>{localStorage.removeItem(SAVE_KEY);$('#modalRoot').innerHTML='';initGame()}}
function askPerson(target){let c=state.case;if(c.actions<=0||c.day>=c.days)return say('本日の行動回数を使い切りました');let title='',answer='';
 if(target==='defendant'){title=`被告人 ${c.defendant} への質問`;answer=pick([`事件発生時刻の${c.when}、あなたは${c.where}にいましたか。`,`「${c.motive}」が事件に関係したという指摘について、どう説明しますか。`,`事件当日の行動を、記録と照らし合わせて順番に説明してください。`])+`\n\n被告人：その点については、私の記憶では一部違います。${c.hiddenTwist}。ただ、記録を見れば説明できると思います。`}
 else if(target==='witness'){title=`証人 ${c.witnessName} への尋問`;answer=`裁判官：事件当時、どの位置から何を見聞きしましたか。\n\n証人：${pick([`現場から少し離れた場所にいました。人物の顔までははっきり見えませんでした。`,`音がしたので振り返りました。時間については正確ではありません。`,`現場付近を通りましたが、視界の一部が遮られていました。`,`最初に警察へ話した内容と、今の記憶に少し違いがあります。`])} ${c.hiddenTwist}`}
 else if(target==='prosecution'){title=`検察官 ${c.prosecutor} への質問`;answer=`裁判官：検察官、立証の中心となる証拠と、その限界を説明してください。\n\n検察官：中心となるのは${c.evidence[0].title}です。${c.evidence[0].detail} ただし、他の証拠と総合して評価いただきたいと考えます。`}
 else {title=`弁護人 ${c.defense} への質問`;answer=`裁判官：弁護人、合理的な疑いが残るとする具体的な根拠を示してください。\n\n弁護人：${c.hiddenTwist}。さらに、${c.evidence[1]?.title||'提出資料'}についても別の説明が成り立ちます。検察側の仮説だけで結論を出すべきではありません。`}
 c.actions--;pushLog(`${title}。回答を法廷記録に追加した。`);$('#speeches').insertAdjacentHTML('beforeend',`<div class="speech judge"><div class="speech-mark">裁</div><div><div class="speech-label">JUDICIAL QUESTION · ${esc(title)}</div><div class="speech-text">${esc(answer).replace(/\n/g,'<br>')}</div></div></div>`);autoSave();render();say('質問と回答を記録しました');showModal(title,`<div class="question-paper">${esc(answer).replace(/\n/g,'<br>')}</div><p class="side-intro">この回答を他の証拠・供述と照らし合わせてください。</p>`);}
function listenCounsel(target){let c=state.case;if(c.actions<=0||c.day>=c.days)return say('本日の行動回数を使い切りました');c.actions--;let defense=target==='defense',speech=actorSpeech(defense?'defense':'prosecution');pushLog(`${defense?'弁護人':'検察官'}の追加意見を聴取。`);autoSave();render();showModal(defense?'弁護人の追加意見':'検察官の追加意見',`<div class="question-paper">${esc(speech)}</div><p>裁判官として、この主張を裏付ける証拠と反対の説明を確認してください。</p>`);}
function handleAction(kind){if(kind==='evidence'||kind==='witness'||kind==='defendant'){if(state.case.actions<=0)return say('本日の行動回数を使い切りました');revealEvidence(kind)}else if(kind==='next')nextDay();else if(kind==='verdict')verdictModal()}
$('#newGameBtn').onclick=()=>{localStorage.removeItem(SAVE_KEY);initGame()};$('#continueBtn').onclick=resumeGame;$('#saveBtn').onclick=save;$('#menuBtn').onclick=()=>showModal('任期メニュー',`<p>審理記録はこの端末のブラウザ内に保存されます。別の端末やブラウザとは共有されません。</p><div class="modal-actions"><button class="paper-btn alt" id="menuClose">戻る</button><button class="paper-btn" id="saveMenu">保存する</button></div>`);$('#soundBtn').onclick=()=>{soundOn=!soundOn;$('#soundBtn').textContent=soundOn?'音 ON':'音 OFF';beep(560,.08)};$('#openNewsBtn').onclick=showNews;
$('#menuClose')?.addEventListener('click',()=>$('#modalRoot').innerHTML='');
$('#actionRow').addEventListener('click',e=>{let b=e.target.closest('[data-action]');if(b)handleAction(b.dataset.action)});
$('.tabbar').addEventListener('click',e=>{let b=e.target.closest('[data-tab]');if(!b)return;activeTab=b.dataset.tab;$$('.tab-btn').forEach(x=>x.classList.toggle('active',x===b));renderTab()});
$('#tabContent').addEventListener('click',e=>{let b=e.target.closest('[data-evidence-index]');if(!b)return;revealEvidence('evidence',Number(b.dataset.evidenceIndex))});
$('#tabContent').addEventListener('click',e=>{let a=e.target.closest('[data-ask]');if(a){askPerson(a.dataset.ask);return}let l=e.target.closest('[data-listen]');if(l){listenCounsel(l.dataset.listen);return}if(e.target.closest('#sidebarVerdict')){verdictModal();return}if(e.target.closest('#recordPrint')){showModal('事件記録',document.querySelector('.file-paper')?.outerHTML||'');return}});
$('#modalRoot').addEventListener('click',e=>{if(e.target.id==='saveMenu'){save();$('#modalRoot').innerHTML=''}if(e.target.id==='menuClose')$('#modalRoot').innerHTML=''});
const existing=load();if(existing&&existing.case)$('#continueBtn').classList.remove('hidden');else $('#continueBtn').classList.add('hidden');
})();
